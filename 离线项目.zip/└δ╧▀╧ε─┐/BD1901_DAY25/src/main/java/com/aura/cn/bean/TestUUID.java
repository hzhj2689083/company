package com.aura.cn.bean;

import java.util.UUID;

public class TestUUID {
	public static void main(String[] args) {
		UUID randomUUID = UUID.randomUUID();
		System.out.println(randomUUID);
	}

}
