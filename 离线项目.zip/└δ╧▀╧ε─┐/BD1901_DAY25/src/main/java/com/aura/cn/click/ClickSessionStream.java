package com.aura.cn.click;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.UUID;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import com.aura.cn.bean.WebLogBean;

/*
 * 抽取   转换   点击会话流的   数据  
 * 	map端：
 * 		9个字段
		key： ip 
		value： 自定义类   字符串   WebLogBean
	reduce：
		相同ip的数据 
		排序   按照访问时间  升序  排序
		计算相邻两个的时间差
		判断
 */
public class ClickSessionStream {
	static class ClickSessionStreamMapper extends Mapper<LongWritable, Text, 
	Text, WebLogBean>{
		Text mk=new Text();
		WebLogBean bean=new WebLogBean();
		@Override
		protected void map(LongWritable key, Text value, Mapper<LongWritable, Text, Text, WebLogBean>.Context context)
				throws IOException, InterruptedException {
			String line = value.toString();
			String[] pre_datas = line.split("\001");
			if(pre_datas.length==9){
				///wp-content/uploads/2013/07/rstudio-git3.png3040"-"Mozilla/4.0 (compatible;)
				bean.setValid(pre_datas[0].equals("true")?true:false);
				bean.setRemote_addr(pre_datas[1]);
				bean.setRemote_user(pre_datas[2]);
				bean.setTime_local(pre_datas[3]);
				bean.setRequest(pre_datas[4]);
				bean.setStatus(pre_datas[5]);
				bean.setBody_bytes_sent(pre_datas[6]);
				bean.setHttp_referer(pre_datas[7]);
				bean.setHttp_user_agent(pre_datas[8]);
				//数据需要过滤的  非法数据  过滤 
				if(bean.isValid()){
					mk.set(bean.getRemote_addr());
					context.write(mk, bean);
				}
			}
		}
		
	}
	
	static class ClickSessionStreamReducer extends Reducer<Text, WebLogBean, Text, NullWritable>{
		Text rk=new Text();
		@Override
		protected void reduce(Text key, Iterable<WebLogBean> values,
				Reducer<Text, WebLogBean, Text, NullWritable>.Context context) throws IOException, InterruptedException {
			/*
			 * reduce端  迭代器：
			 * 	1） 只能循环遍历一次
			 * 	2）对象重用
			 * 相同ip的所有数据    多个session
			 * 循环遍历  迭代器中的每一个对象  放在一个list集合中  排序  时间  升序
			 */
			/*
			 * reduce的两个坑：
			 * 	1）k  随着value的变化而变化的
			 * 	2）k   v     只能遍历一次
			 */
			ArrayList<WebLogBean> list=new ArrayList<WebLogBean>();
			
			/*for(WebLogBean w:values){
				list.add(w);
			}*/
			
			
			for(WebLogBean v:values){
				//新建一个对象
				WebLogBean bean=new WebLogBean();
				//将 迭代器中的对象的属性  复制到新对象上就可以
				//参数1  目标对象 新对象   参数2：原始对象   
				try {
					//BeanUtils   工具类     copyProperties  拷贝属性的
					BeanUtils.copyProperties(bean, v);
					list.add(bean);
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			//对list集合中的数据  排序   按照时间排序  参数2：比较器   外部
			Collections.sort(list, new Comparator<WebLogBean>() {

				public int compare(WebLogBean o1, WebLogBean o2) {
					//取出两个对象的时间进行比较  string   2019-04-08 23:12:12
					Date date1=null;
					Date date2=null;
					try {
						date1 = toDate(o1.getTime_local());
						date2 = toDate(o2.getTime_local());
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					if(date1==null || date2==null){
						return 0;
					}
					return date1.compareTo(date2);
				}
			});
			
			
			//循环遍历  list集合中的对象了      算停留时间    session  step
			int step=1;
			UUID sessionid = UUID.randomUUID();
			for(int i=0;i<list.size();i++){
				WebLogBean bean = list.get(i);
				//只有一个访问的信息   将session  step  1   停留时间  30s
				if(list.size()==1){
					rk.set(sessionid+"\001"+bean.getRemote_addr()+"\001"+
							bean.getRemote_user()+"\001"+bean.getTime_local()+"\001"+
							bean.getRequest()+"\001"+(30)+"\001"+step+"\001"+bean.getStatus()+"\001"+
							bean.getBody_bytes_sent()+"\001"+bean.getHttp_referer()+"\001"+
							bean.getHttp_user_agent());
					context.write(rk, NullWritable.get());
					//给sessionid 重新赋值
					sessionid=UUID.randomUUID();
					break;
				}
				//多余一个  
				//时间差 
				//有多个     计算时间差   第一条数据    每一条-上一条的  从第二条开始算
				if(i==0){
					continue;
				}
				//处理第二条数据开始  求时间差  当前-前一个=前一个
				try {
					long diffDate = diffDate(bean.getTime_local(), list.get(i-1).getTime_local());
					//判断时间差  小于30min的
					if(diffDate < 30*60*1000){
						//输出上一个数据 最后一个数据  没有输出的  同一个会话的
						WebLogBean lb=list.get(i-1);
						rk.set(sessionid+"\001"+lb.getRemote_addr()+"\001"+
							lb.getRemote_user()+"\001"+lb.getTime_local()+"\001"+
							lb.getRequest()+"\001"+(diffDate)/1000+"\001"+step+"\001"+lb.getStatus()+"\001"+
							lb.getBody_bytes_sent()+"\001"+lb.getHttp_referer()+"\001"+
							lb.getHttp_user_agent());
						context.write(rk, NullWritable.get());
						step++;
						/* 12:15
						 * 12:20
						 * 12:30
						 * 
						 * 15:30
						 * 
						 */
					}else{//   默认的是一个新的session
						//上一个会话已经结束了  可以输出上一个会话的最后一个数据的
						WebLogBean lsl=list.get(i-1);
						rk.set(sessionid+"\001"+lsl.getRemote_addr()+"\001"+
							lsl.getRemote_user()+"\001"+lsl.getTime_local()+"\001"+
							lsl.getRequest()+"\001"+(30)+"\001"+step+"\001"+lsl.getStatus()+"\001"+
							lsl.getBody_bytes_sent()+"\001"+lsl.getHttp_referer()+"\001"+
							lsl.getHttp_user_agent());
						context.write(rk, NullWritable.get());
						//session重新复制
						//step重新赋值
						step=1;
						sessionid=UUID.randomUUID();
						
					}
					
					//输出最后一个数据   同一个ip的最后一个数据 
					if(i==(list.size()-1)){
						WebLogBean cb=list.get(i);
						rk.set(sessionid+"\001"+cb.getRemote_addr()+"\001"+
							cb.getRemote_user()+"\001"+cb.getTime_local()+"\001"+
							cb.getRequest()+"\001"+(30)+"\001"+step+"\001"+cb.getStatus()+"\001"+
							cb.getBody_bytes_sent()+"\001"+cb.getHttp_referer()+"\001"+
							cb.getHttp_user_agent());
						context.write(rk, NullWritable.get());
					}
					
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				
			}
			
		}
		
		
		public static Date toDate(String time) throws ParseException{
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			Date date = sdf.parse(time);
			return date;
		}
		//参数1： 当前时间 参数2：上一条数据时间
		public static long diffDate(String date1,String date2) throws ParseException{
			Date d1 = toDate(date1);
			Date d2 = toDate(date2);
			return d1.getTime()-d2.getTime();
		}
		
	}
	public static void main(String[] args) throws ClassNotFoundException, IOException, InterruptedException {
		System.setProperty("HADOOP_USER_NAME", "hadoop");
        Configuration conf = new Configuration();
        conf.set("fs.defaultFS", "hdfs://bd1901/");
        Job job = Job.getInstance(conf);

        job.setJarByClass(ClickSessionStream.class);

        job.setMapperClass(ClickSessionStreamMapper.class);
        job.setReducerClass(ClickSessionStreamReducer.class);
        
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(WebLogBean.class);
        
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(NullWritable.class);

        FileInputFormat.setInputPaths(job, new Path("/data/pre/20190604"));
        Path out=new Path("/data/click/stream/20190604");
        FileSystem fs=FileSystem.get(conf);
        if(fs.exists(out)){
        	fs.delete(out, true);
        }
        FileOutputFormat.setOutputPath(job,out );


        boolean res = job.waitForCompletion(true);
        System.exit(res ? 0 : 1);
	}
	
	
	

}
