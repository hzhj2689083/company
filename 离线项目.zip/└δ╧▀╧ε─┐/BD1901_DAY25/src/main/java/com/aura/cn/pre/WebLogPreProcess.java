package com.aura.cn.pre;
//对原始数据进行预处理

import java.io.IOException;
import java.text.ParseException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import com.aura.cn.bean.WebLogBean;

public class WebLogPreProcess {
	/*
	 * map端：
		一行数据--- 一条日志--- hive一条数据
		切分  封装对象  发送  写出hdfs
		key：null
		value：自定义对象
	 */
	static class WebLogPreProcessMapper extends Mapper<LongWritable, Text, NullWritable, WebLogBean>{
		//194.237.142.21 - - [18/Sep/2013:06:49:18 +0000] "GET /wp-content/uploads/2013/07/rstudio-git3.png HTTP/1.1" 304 0 "-" "Mozilla/4.0 (compatible;)"
		@Override
		protected void map(LongWritable key, Text value,
				Mapper<LongWritable, Text, NullWritable, WebLogBean>.Context context)
				throws IOException, InterruptedException {
			//获取一行内容
			String line = value.toString();
			try {
				WebLogBean webLogBean=WebLogParse.parse(line);
				if(webLogBean!=null){
					context.write(NullWritable.get(), webLogBean);
				}
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}
	
	public static void main(String[] args) throws ClassNotFoundException, IOException, InterruptedException {
		System.setProperty("HADOOP_USER_NAME", "hadoop");
        Configuration conf = new Configuration();
        conf.set("fs.defaultFS", "hdfs://bd1901/");
        Job job = Job.getInstance(conf);

        job.setJarByClass(WebLogPreProcess.class);

        job.setMapperClass(WebLogPreProcessMapper.class);
        job.setOutputKeyClass(NullWritable.class);
        job.setOutputValueClass(WebLogBean.class);

        FileInputFormat.setInputPaths(job, new Path("/flume/log/20190604"));
        FileOutputFormat.setOutputPath(job, new Path("/data/pre/20190604"));

        //不需要  设置为0 
        job.setNumReduceTasks(0);

        boolean res = job.waitForCompletion(true);
        System.exit(res ? 0 : 1);
	}

}
