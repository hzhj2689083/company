package com.aura.cn.pre;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

import com.aura.cn.bean.WebLogBean;

//解析原始数据的  封装为  weblogbean
public class WebLogParse {

	static SimpleDateFormat sdf1=new SimpleDateFormat("dd/MMM/yyyy:hh:mm:ss", Locale.US);
	static SimpleDateFormat sdf2=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
	static Set<String> pages=new HashSet<String>();
	static {
		/*
		 * 静态页面   html  css js
		 * 图片   png
		 * 响应  不是 200 
		 */
		pages.add("/about");
        pages.add("/black-ip-list/");
        pages.add("/cassandra-clustor/");
        pages.add("/finance-rhive-repurchase/");
        pages.add("/hadoop-family-roadmap/");
        pages.add("/hadoop-hive-intro/");
        pages.add("/hadoop-zookeeper-intro/");
        pages.add("/hadoop-mahout-roadmap/");
	}
	//参数代表一行日志信息
	public static WebLogBean parse(String line) throws ParseException {
		String[] log_datas = line.split(" ");
		if(log_datas.length>=12){
			//合法数据  字段不缺的
			
			/*
			 * [194.237.142.21, -, -, [18/Sep/2013:06:49:18,+0000], "GET, 
			 * /wp-content/uploads/2013/07/rstudio-git3.png, HTTP/1.1", 304, 0, "-", 
			 * "Mozilla/4.0, (compatible;)"]
			 */
			String addr=log_datas[0];
			String user=log_datas[2];
			String local_time=log_datas[3];
			//对时间解析  
			String format_time = sdf2.format(sdf1.parse(local_time.substring(1)));
			if(null == format_time || "".equals(format_time)){
				format_time="_invalid_";
			}
			//请求
			String request=log_datas[6];
			String status=log_datas[8];
			String byte_sent=log_datas[9];
			String http_refer=log_datas[10];
			//拼接浏览器信息
			StringBuffer sb=new StringBuffer();
			for(int i=11;i<log_datas.length;i++){
				sb.append(log_datas[i]+" ");
			}
			String user_agent=sb.substring(1, sb.length()-2);
			//参数1   数据是否有效  有效的  true   无效的  false
			//默认  false的
			WebLogBean bean=new WebLogBean(false, 
					addr, 
					user, format_time, request, status, byte_sent, http_refer, user_agent);
			//判断数据的有效性
			if("_invalid_".equals(format_time)){
				bean.setValid(false);
			}
			//响应  404的   500 》400 
			if(Integer.parseInt(bean.getStatus())>400){
				bean.setValid(false);
			}
			//  静态资源的请求  无效的  正则  表达式  request
			//需要分析的  请求   配置文件中 

	        /**
	         * 从外部配置文件中加载网站的有用url分类数据 存储到maptask的内存中，用来对日志数据进行过滤
	         */
			if(pages.contains(bean.getRequest())){
				bean.setValid(true);
			}
	       return bean;
			
		}else{
			return null;
		}
	}
	public static void main(String[] args) {
		/*String str="194.237.142.21 - - [18/Sep/2013:06:49:18 +0000] \"GET /wp-content/uploads/2013/07/rstudio-git3.png HTTP/1.1\" 304 0 \"-\" \"Mozilla/4.0 (compatible;)\"";
		System.out.println(Arrays.toString(str.split(" ")));*/
		System.out.println(UUID.randomUUID());
	}
	
	

}
